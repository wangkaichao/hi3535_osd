//#include "Client.h"
#include <fcntl.h>
#include "NetLib.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/types.h>          /* See NOTES */
#include <sys/socket.h>
#include <string.h>
#include <netinet/in.h>
#include <sys/stat.h>
#include <pthread.h>
#include <fcntl.h>

typedef struct sockaddr_in SA4;
typedef struct sockaddr SA;

#define USE_DEBUG   (1)
#if USE_DEBUG

#define logErr(...) do {\
          printf("[%s:%d]", __FUNCTION__, __LINE__); \
          printf(__VA_ARGS__); \
          printf("\n"); \
} while (0)

#define logDbg(...) do {   \
          printf("[%s:%d]", __FUNCTION__, __LINE__); \
          printf(__VA_ARGS__); \
          printf("\n"); \
} while (0)

#else

#define logErr(...) 
#define logDbg(...) 

#endif

#define SERVER_PROT (6789)

#define NET_ID          (0X5555AAAA)
#define NET_DATA_SIZE   (200*1024)

#define WM_USER         (0X0400)
#define NET_CMD_LOGIN   (WM_USER + 100)
#define NET_CMD_LOGOUT  (WM_USER + 101)
#define NET_CMD_ENFACE  (WM_USER + 102)
#define NET_CMD_FACE    (WM_USER + 103)
#define NET_CMD_HEART   (WM_USER + 104)
#define NET_CMD_EXIT    (WM_USER + 105)

static int isIP(const char *p)
{
    return 1;
}

static int isPort(short port)
{
    return (port > 0 && port < 65535);
}


typedef struct {
    int m_id;
    int m_type;
    int m_status;
    int m_size;
}net_msg_head_st;

typedef struct {
    net_msg_head_st m_head;
    unsigned char m_data[NET_DATA_SIZE];
}net_msg_st;

typedef struct{
    int sock;
    int rcv_stat;
    net_msg_st rcvMsg;
    net_msg_st sndMsg;
    pthread_t rcv_thread_id;
    v_func_st cap_callback;
}net_sdk_st;
static void *rcv_thread(void *arg);
static int procRcvMsg(long handle);


NETLIB_API int NetLib_Open(long *handle,const char *ip,short port){
   if(handle == NULL || !isIP(ip) || !isPort(port)){
       logErr("open--");
       return -1;
   }
   int fd;
   SA4 serv;
   fd = socket(AF_INET,SOCK_STREAM,0);

   if(fd == -1){
        perror("socket:");
        return -1;
   }
    serv.sin_family = AF_INET;
    serv.sin_port = htons(port);
    inet_pton(AF_INET,ip,&serv.sin_addr);
    if(connect(fd,(SA*)&serv,sizeof(SA4)) == -1){
        perror("connect:");
        return -1;
    }
    net_sdk_st *p = (net_sdk_st *)malloc(sizeof(net_sdk_st));
    memset(p,0,sizeof(net_sdk_st));
    p->sock = fd;
    p->rcv_stat = 0;
    
    if(pthread_create(&p->rcv_thread_id,NULL,rcv_thread,p) != 0){//创建一个线程读取服务器传输回来的数据
        perror("pthread_create");
        return -1;
    }
    /*if(pthread_detach(p->rcv_thread_id) !=0){//线程分离
        perror("pthread_datach");
        return -1;
    }*/
    *handle = (long)p;
    printf("%ld\n",*handle);
    logDbg("------ok");
    return 0;
}

NETLIB_API int NetLib_Close(long *handle){
    if(!handle || !*handle)
        return -1;
    void *ret;
    net_sdk_st *p = (net_sdk_st *)(*handle);
    //pthread_join(p->rcv_thread_id,&ret);
    close(p->sock);
    pthread_cancel(p->rcv_thread_id);
    pthread_join(p->rcv_thread_id,&ret);//等待读线程的汇合
    logDbg("------close ok");
    free(p);
    *handle = 0;
    logDbg("----ok");
    return 0;
}

NETLIB_API int NetLib_Login(long *handle,const net_login_st *pst_login){
    if(!handle || !*handle || !pst_login){
        logErr("NetLib_Login");
        return -1;
    }
    net_sdk_st *p = (net_sdk_st*)(*handle);
    memset(&p->sndMsg,0,sizeof(net_msg_st));
    p->sndMsg.m_head.m_id = NET_ID;
    p->sndMsg.m_head.m_type = NET_CMD_LOGIN;
    p->sndMsg.m_head.m_status = 0;
    p->sndMsg.m_head.m_size = sizeof(net_login_st);
    memcpy(&p->sndMsg.m_data,pst_login,sizeof(net_login_st));
    if(write(p->sock,&p->sndMsg,(sizeof(net_msg_head_st) + p->sndMsg.m_head.m_size) )==-1){
        perror("write:");
        return -1;
    }
    while(p->rcv_stat != 1);
    /*if(read(p->sock,&p->rcvMsg.m_head,sizeof(net_msg_head_st)) == -1){
        perror("in_read_1");
        return -1;
    }
    if(read(p->sock,p->rcvMsg.m_data,p->rcvMsg.m_head.m_size) == -1){
        perror("in_read_2");
        return -1;
    }*/
    return p->rcvMsg.m_head.m_status;
}


NETLIB_API int NetLib_Logout(long *handle){
    if(!handle || !*handle )
        return -1;
    net_sdk_st *p = (net_sdk_st*)(*handle);
    p->sndMsg.m_head.m_id = NET_ID;
    p->sndMsg.m_head.m_type = NET_CMD_LOGIN;
    p->sndMsg.m_head.m_status = 0;
    p->sndMsg.m_head.m_size =0; 
    if(write(p->sock,&p->sndMsg,(sizeof(net_msg_head_st)+p->sndMsg.m_head.m_size))==-1){
        perror("write:");
        return -1;
    }
    /*if(read(p->sock,&p->rcvMsg.m_head,sizeof(net_msg_head_st)) == -1){
        perror("in_read_1");
        return -1;
    }
    if(p->rcvMsg.m_head.m_size == 0)
        return 0;
    if(read(p->sock,p->rcvMsg.m_data,p->rcvMsg.m_head.m_size)){
        perror("in_read_2");
        return -1;
    }*/
    logDbg("------ok");
    return p->rcvMsg.m_head.m_status;
}

NETLIB_API int NetLib_CapFace(long *handle,int enable,v_func_st callback){
    if(!handle || !(*handle))
        return -1;
    int rcv;
    net_sdk_st *p = (net_sdk_st *)*handle;
    memset(&p->sndMsg,0,sizeof(net_msg_st));
    p->sndMsg.m_head.m_id = NET_ID;
    p->sndMsg.m_head.m_type = NET_CMD_ENFACE;
    p->sndMsg.m_head.m_status = 0;
    p->sndMsg.m_head.m_size = sizeof(int);
    memcpy(p->sndMsg.m_data,&enable,p->sndMsg.m_head.m_size);
    if(write(p->sock,&p->sndMsg,(sizeof(net_msg_head_st) + p->sndMsg.m_head.m_size)) == -1){
        perror("cap_write");
        return -1;
    }
    /*if(pthread_create(&p->rcv_thread_id,NULL,rcv_thread,p) != 0){
        perror("pthread_create");
        return -1;
    }
    if(pthread_detach(p->rcv_thread_id) !=0){
        perror("pthread_datach");
        return -1;
    }*/
    while(p->rcv_stat != 1);
        p->cap_callback = callback;
    return 0;
    /*while(1){
        if(read(p->sock,&p->rcvMsg.m_head,sizeof(net_msg_head_st)) == -1)
            //if(recv(p->sock,&p->rcvMsg,(sizeof(net_msg_head_st)+p->rcvMsg.m_head.m_size),0)  == -1)
        {
            perror("cap_read_1");
            return -1;
        }
        if(p->rcvMsg.m_head.m_size == 0)
          continue;*/
      /*  if( rcv = recv(p->sock,p->rcvMsg.m_data,p->rcvMsg.m_head.m_size,0)){
            //if(read(p->sock,p->rcvMsg.m_data,p->rcvMsg.m_head.m_size) == -1){
            if(rcv == -1){
                perror("cap_read_2");
                return -1;
            }
            else if(rcv == p->rcvMsg.m_head.m_size){
                if(procRcvMsg((long)p) == 0)
                    p->cap_callback = callback;
            }
        }
    }*/
}

int RcvMsg(int sock,void *buf , int size){
    int rcv = 0;
    while(size - rcv){
        rcv = recv(sock,buf,size,0);
        printf("size-rcv = %d\n",size-rcv);
        if(rcv < 0){
            perror("RcvMsg recv error");
            return -1;
        }else if(rcv < size){
            buf += rcv;
            size -= rcv;
        }
    }
    return 0;
}

void *rcv_thread(void *arg){//读线程执行的函数
    int rcv;
    int stat;
    net_sdk_st *p = (net_sdk_st *)arg;
    while(1){
        rcv = RcvMsg(p->sock,&p->rcvMsg.m_head,sizeof(net_msg_head_st));
        if(rcv < 0)
            break;
        p->rcv_stat = 1;
        if(p->rcvMsg.m_head.m_size != 0){
            rcv = RcvMsg(p->sock,p->rcvMsg.m_data,p->rcvMsg.m_head.m_size);
            if(rcv < 0)
                break;
            else
                stat = procRcvMsg((long)p);
            if(stat == 3)
                break;
            p->rcv_stat = 1;
        }
        /*if(read(p->sock,&p->rcvMsg.m_head,sizeof(net_msg_head_st)) == -1)
        {
            perror("cap_read_1");
            return (void *)-1 ;
        }
        p->rcv_stat = 1;
        if( rcv = recv(p->sock,p->rcvMsg.m_data,p->rcvMsg.m_head.m_size,0)){
            if(rcv == -1){
                perror("cap_read_2");
                return (void *) -1;
            }
            //rcv_stat = 1;
            else if(rcv == p->rcvMsg.m_head.m_size){
                stat = procRcvMsg((long)p);
                if(stat == 0)
                    p->rcv_stat = 1;
                //p->cap_callback = callback;
                else if(stat == 3){
                    logErr("procRcvMsg err %d",stat);
                    break;
                }            
            }
        }*/

    }

    pthread_exit((void *)0);//读线程的退出
}

int procRcvMsg(long handle){
    int stat = 0;
    net_sdk_st *p = (net_sdk_st *)handle;
    switch (p->rcvMsg.m_head.m_type) {
        case NET_CMD_LOGIN:printf("NET_CMD_LOGIN\n");stat = 0;break;
        case NET_CMD_LOGOUT:printf("NET_CMD_LOGOUT\n");stat = 3;break;
        case NET_CMD_ENFACE:printf("NET_CMD_ENFACE\n");p->rcv_stat =1;stat = 1;break;
            //if(recv(p->sock,&p->rcvMsg,(sizeof(net_msg_head_st)+p->rcvMsg.m_head.m_size),0)  == -1)
        default:printf("Undefined cmd\n");stat = 3;break;
    }
    return stat;
}


























